
function inicializa(){
	console.log("Cargado");
	
}

